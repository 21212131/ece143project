# ece143project
degrees-that-pay-back.csv and salaries-by-college.csv are datasets. Keep these in the same folder as the code.
.ipynb files are code. Run as usual. Plots are already shown in the notebooks.

To do:


Clean up code, divide into folders add comments and asserts
